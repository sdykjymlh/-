#!/bin/bash
awk -F "[/:]" '$7":"$8>="13:30" && $7"":"$8<="14:30"'  /var/log/httpd/access_log |wc -l
