#!/bin/bash
read -p "请输入存放证书的目录:" dir 
if [ ! -d $dir ];then 
  echo "该目录不存在" 
  exit 
fi 
read -p "请输入密钥名称:" name 
openssl genrsa -out ${dir}/${name}.key 
openssl req -new -x509 -key ${dir}/${name}.key -subj "/CN=common" -out ${dir}/${name}.crt 
