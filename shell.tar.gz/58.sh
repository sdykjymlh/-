#!/bin/bash
for i in {1..3}
do
read -p "请输入用户名:" user
read -p "请输入密码"  pass
if [ "$user" == 'tom' -a "$pass" == '123456' ];then
echo "Login successful"
	exit
fi
done
	echo "Login Failed"
