#!/bin/bash
sed -i '/^SElINUX/s/=.*/=disabled/' /etc/selinux/config
setenforce 0
