#!/bin/bash
log_file=/var/log/mysql_count.log
user=root
passwd=123456
while :
do
      sleep 2
	count=`mysqladmin -u "$user" -p "passwd" status | awk '{print $4}'`
	echo "`date +%y-%m-%d`并发连接数为:$count" >> $log_file

