#!/bin/bash
#RANDOM 为系统自带的环境变量,值为0-32767的随机数
#使用取余算法将随机数变为1-100的随机数
num=$[RANDOM%100+1]
while :
do 
read -p "计算机生成了一个1-100的随机数,你猜: " cai
if [ $cai -eq $num ];then
   echo "恭喜,猜对了." 
       exit 0  
elif [ $cai -gt $num ];then
   echo "抱歉,猜大了.请继续" 
              
else 
   echo "抱歉,猜小了.请继续" 
              
fi
done
