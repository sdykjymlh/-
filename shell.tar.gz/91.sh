#!/bin/bash
virt-df 
read -n1 "按任意键继续" key
virt-top

