#!/bin/bash
#定义一个函数,ping某台主机,并检测主机的存活状态
myping(){
ping -c2 -i0.3 -w1 $1 &>/dev/null
if [ $? -eq 0 ];then
    echo "$1 is up"
else 
    echo "$1 is down"
fi
}
for i in {1..254}
do
  myping 192.168.4.$i &
done
#使用&符号,将执行的函数放入后台执行
#好处是不需要等待第一台主机的回应,就行可以进行下一台.

