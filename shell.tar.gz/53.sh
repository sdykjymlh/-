#!/bin/bash
tr -dc '_A-Za-Z0-9' </dev/urandom | head -c 10
