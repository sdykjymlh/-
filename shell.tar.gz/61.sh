#!/bin/bash
awk -F: '{print $1}' /etc/passwd

cut -d: 9f1 /etc/passwd

sed 's/:.*//' /etc/passwd
