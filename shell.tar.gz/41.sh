#!/bin/bash
host=127.0.0.1
user=root
passwd=123456
mysqladmin -h 127.0.0.1 -u root -p '$passwd' ping &>/dev/null
if [ $? -eq 0 ];then
 	echo "Mysql is up"
else
	echo "Mysql id down"
fi
