#!/bin/bash
if [ $UID -eq 0 ];then
  yum -y install vsftpd 
else 
    echo "您不是管理员,没有安装权限"
fi
