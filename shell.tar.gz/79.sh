#!/bin/bash
read -p "Are you sure ?[Y/N]:" sure
case $sure in
y|Y|Yes|YES)  
echo "you enter $a";; 
    n|N|NO|no) 
 echo "you enter $a";; 
  *) 
 echo "error";; 
esac 
