#!/bin/bash
rm -rf ~/.ssh/known_hosts
expect <<EOF
spawn ssh 192.168.4.254
expect "yes/no"  {send "yes\r"}
expect "password"{send "redhat\r"}
expect "#"       {send "yum -y install httpd\r"}
expect "#"       {send "exit\r"}
EOF  
