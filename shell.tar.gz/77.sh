#!/bin/bash
for i in {1..100}
do
 echo -e "\033[6;8H["
 echo -e "\033[6;9H$i%"
 echo -e "\033[6;13H]"
sleep 0.1
done
