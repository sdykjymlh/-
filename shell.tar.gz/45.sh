#!/bin/bash
if [ $# -eq 0 ];then
echo "你需要制定一个软件包名称作为脚本参数"
echo "用法:$0 软件包名称..."
fi
for package in "$@"
do
if [ rpm -q ${package} &> /dev/null ];then
    echo -e "${package}\033[32m已经安装\033[0m"
else
	echo -e "${package}\033[32m未安装\033[0m"
fi
done
