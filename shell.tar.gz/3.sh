#!/bin/bash
tar -czf log-`date+%Y%d`.tar.gz /var/olg
# 脚本编写后,编写计划任务执行脚本.
#crentab -e 
#00 03 * * 5 该脚本绝对路径
