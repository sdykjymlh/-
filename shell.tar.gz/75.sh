#!/bin/bash
read -p "请输入积分(0-100):" JF 
if [ $JF -ge 90 ] ; then 
    echo "$JF 分,神功绝世" 
elif [ $JF -ge 80 ] ; then 
    echo "$JF 分,登峰造极"
elif [ $JF -ge 70 ] ; then 
    echo "$JF 分,炉火纯青" 
elif [ $JF -lt 60 ] ; then 
    echo "$JF 分,略有小成" 
else 
    echo "$JF 分,初学乍练"
fi 
