#!/bin/bash
#yum需要提前备好.
yum -y install httpd
yum -y install mariadb mariadb-server mariadb-devel
yum -y install php php-fpm

systemctl restart mariadb httpd
systemctl enable httpd mariadb
