#!/bin/bash
rpm --quiet -q tigervnc-server
if [ $? -ne 0 ];then
fi
x0vncserver AcceptKeyEvents=0 AlwaysShared=1 \ 
AcceptPointerEvents=0 SecurityTypes=None  rfbport=5908 
