#!/bin/bash
wget http://www.memcached.org/files/memcached-1.5.1.tar.gz 
yum -y install gcc 
tar -xf  memcached-1.5.1.tar.gz 
cd memcached-1.5.1 
./configure 
make 
make install 
