#!/bin/bash
url=http://192.168.4.5/index.html
check_http(){
status_code=$(curl -m -5 -s -o /dev/null -w %{http_code}$url)}
