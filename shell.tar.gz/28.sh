#!/bin/bash
awk -F "[/:]" '$7":"$8>="13:30" && $7"":"$8<="14:30"{print $1}' /var/log/httpd/access_log 
