#!/bin/bash
#方法一
grep "bash$" /etc/passwd |wc -l
#方法二
#awk -f: '/bash$/{x++}END{print x}' /etc/passwd
