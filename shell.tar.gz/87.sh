#!/bin/bash
trap 'echo "暂停 10s";sleep 10'  2 
while : 
do 
    echo "go go go" 
done
