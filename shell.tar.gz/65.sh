#!/bin/bash
for i in {1..254}
do
[ $i -eq 100 ]&& contiue
echo "正在关闭 192.168.4.$i..."
ssh 192.168.4.$i poweroff
done
