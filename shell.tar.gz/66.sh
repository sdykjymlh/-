ip a s |awk 'BEGIN{print "本机 mac 地址信息如下 :"}/^[0-9]/{print $2 getline;if($0~/link\/ether/){print $2}}' |grep -v lo:
