#!/bin/bash
#编写 hello world 脚本
echo "hello world" 
