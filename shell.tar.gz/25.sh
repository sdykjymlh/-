#!/bin/bash
netstat -atn | awk '{print $2}' |awk '{print $1}' |sort -nr | uniq -c
