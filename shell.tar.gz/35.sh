#!/bin/bash
program=/usr/local/nginx/sbin/nginx
pid=/usr/local/nginx/logs/nginx.pid
start(){
if [ -f $pid ];then
	echo "nginx服务已处于开机状态"
else
	$program
fi
}
stop(){
if [ -! -f $pid ];then
	echo "nginx服务已经关闭"
else
  	$program -s stop
	echo "关闭服务成功"
fi
}
status(){
if [ -f $pid ];then
	echo "服务正在运行.."
else
	echo "服务已经关闭"
fi
}

case $1 in 
start)
	start;;
stop)
	stop;;
resatrt)
	stop
	sleep 1
	start;;
status)
	status;;
*)
	echo "你输入的语法错误"
esac

