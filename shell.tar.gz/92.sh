#!/bin/bash
clear 
for (( i=1; i<=9; i++ )) 
do 
    for (( j=1; j<=i; j++ )) 
  do 
      echo ‐n "$i" 
  done 
  echo "" 
done 
read  -n1  "按任意键继续"  key 
clear 
for (( i=1; i<=5; i++ ))
do 
    for (( j=1; j<=i; j++ )) 
  do 
      echo ‐n " |" 
  done 
  echo "_ " 
done 
read  -n1  "按任意键继续"  key 
clear 
for (( i=1; i<=5; i++ )) 
do 
    for (( j=1; j<=i; j++ )) 
  do 
      echo ‐n " *" 
  done 
  echo "" 
done 
 
for (( i=5; i>=1; i‐‐ )) 
do 
  for (( j=1; j<=i; j++ )) 
  do 
       echo ‐n " *" 
  done 
  echo "" 
done 
