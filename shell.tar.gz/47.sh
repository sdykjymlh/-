#!/bin/bash
server='nfs http ssh'
port="80 22 8080"

for i in $service 
do
echo "Adding $i service to firewall"
firewall-cmd --add-service=${i}
done

for i in $port
do 
echo "Adding $i port to firewall"
firewall-cmd --add-port=${i}/tcp
done
firewall -cmd --runtime-to-permanent
