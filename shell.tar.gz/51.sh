#!/bin/bash
ps aux | awk '{if($8 == "z"){print $2,$11}}'
