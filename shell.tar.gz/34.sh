#!/bin/bash
yum -y install gcc readline-devel pcre-devel
useradd -s /sbin/nologin varnish
cd varnish-3.0.6
./configure --perfix=/usr/local/varnish
make && make install
cp redhat/varnish.initrc /etc/init.d/varnish 
cp redhat/varnish.sysconfig /etc/sysconfig/varnish
cp redhat/varnish_reload_vcl /usr/bin/ 
ln ‐s /usr/local/varnish/sbin/varnishd /usr/sbin/ 
ln ‐s /usr/local/varnish/bin/* /usr/bin 
mkdir /etc/varnish
cp /usr/local/varnish/etc/varnish/default.vcl /etc/varnish/ 
uuidgen > /etc/varnish/secret`
